import { Component, OnInit } from '@angular/core';
import { PostService } from '../services/post.service';
import { AppError } from '../common/app-error';
import { NotFoundError } from '../common/not-FoundError';
import { HttpErrorResponse } from '@angular/common/http';



@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  posts: any[] = [];
  constructor(private service: PostService) {
  }

  ngOnInit() {
    this.service.getAll()
      .subscribe(
        (response: any) => {
          console.log(response);
          this.posts = (response);
        },
        (error: any) => { this.handleError(error) });
  }

  getPost(input: HTMLInputElement) {
    if (input.value != "") {
      this.service.get(input.value)
        .subscribe(
          (response: any) => {
            console.log(response);
            this.posts.splice(0, 0, response);
          },
          (error: any) => { this.handleError(error) });
    }
  }

  createPost(input: HTMLInputElement) {
    let post: any = { title: input.value }
    this.service.post(post)
      .subscribe(
        (response: any) => {
          console.log(response);
          post['id'] = response.id;
          this.posts.splice(0, 0, post);
        },
        (error: any) => { this.handleError(error) });
  }

  updatePost(post: any) {
    post.isRead = true;
    this.service.patch(post)
      .subscribe(
        (response: any) => {
          console.log(response);
        },
        (error: any) => { this.handleError(error) });

  }

  deletePost(post: any) {
    this.service.delete(post.id)
      .subscribe(
        (response: any) => {
          console.log(response);
          let index = (this.posts).indexOf(post);
          this.posts.splice(index, 1);
        },
        (error: any) => { this.handleError(error) });
  }

  private handleError(error: AppError) {
   if (error instanceof NotFoundError) {
        console.log("The Id is not available");
    }
    else
    {
      console.log("This is a different error");
    }
    throw (error.originalError as HttpErrorResponse);
  }

}
