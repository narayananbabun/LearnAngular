"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
exports.__esModule = true;
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var customvalidator_1 = require("../common/customvalidator");
var SignupFormComponent = /** @class */ (function () {
    function SignupFormComponent() {
        this.form = new forms_1.FormGroup({
            username: new forms_1.FormControl('', [forms_1.Validators.required, forms_1.Validators.minLength(3), customvalidator_1.customvalidator.cannotContainSpace], [customvalidator_1.customvalidator.shouldBeUnique]),
            // password: new FormControl('',
            //   [Validators.required, Validators.minLength(3), customvalidator.cannotContainSpace],
            //   [customvalidator.shouldBeUnique])
            password: new forms_1.FormControl('', [forms_1.Validators.required, forms_1.Validators.minLength(3), customvalidator_1.customvalidator.cannotContainSpace, forms_1.Validators.maxLength(16),
                forms_1.Validators.pattern(new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*<>])(?=.{8,16})"))
            ], [customvalidator_1.customvalidator.shouldBeUnique])
        });
    }
    Object.defineProperty(SignupFormComponent.prototype, "username", {
        get: function () {
            return this.form.get('username');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SignupFormComponent.prototype, "password", {
        get: function () {
            return this.form.get('password');
        },
        enumerable: true,
        configurable: true
    });
    SignupFormComponent.prototype.log = function (x) {
        console.log(x);
    };
    SignupFormComponent = __decorate([
        core_1.Component({
            selector: 'app-signup-form',
            templateUrl: './signup-form.component.html',
            styleUrls: ['./signup-form.component.css']
        })
    ], SignupFormComponent);
    return SignupFormComponent;
}());
exports.SignupFormComponent = SignupFormComponent;
