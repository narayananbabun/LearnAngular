import { BrowserModule } from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { NgModule, ErrorHandler } from '@angular/core';
import { AppComponent } from './app.component';
import { CoursesComponent } from './courses.component';
import { GamesComponent } from './games/games.component';
import { AuthorsComponent } from './authors/authors.component';
import { AuthorsService } from './services/authors.service';
import { SummaryPipe } from './summary.pipe';
import { FavouriteComponent } from './favourite/favourite.component';
import { MovieComponent } from './movie/movie.component';
import { TitlecasePipe } from './titlecase.pipe';
import { PanelComponent } from './panel/panel.component';
import { LovetweetComponent } from './lovetweet/lovetweet.component';
import { DirectivesComponent } from './directives/directives.component';
import { InputFormatDirective } from './input-format.directive';
import { ZippyComponent } from './zippy/zippy.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { CreatecourseFormComponent } from './createcourse-form/createcourse-form.component';
import { SignupFormComponent } from './signup-form/signup-form.component';
import { NewteamFormComponent } from './newteam-form/newteam-form.component';
import { ChangepasswordFormComponent } from './changepassword-form/changepassword-form.component';
import { PostsComponent } from './posts/posts.component';
import { HttpClientModule } from '@angular/common/http';
import { AppError } from './common/app-error';
import { AppErrorHandler } from './common/apperrorhandler';


@NgModule({
  declarations: [
    AppComponent,
    CoursesComponent,
    GamesComponent,
    AuthorsComponent,
    SummaryPipe,
    FavouriteComponent,
    MovieComponent,
    TitlecasePipe,
    PanelComponent,
    LovetweetComponent,
    DirectivesComponent,
    InputFormatDirective,
    ZippyComponent,
    ContactFormComponent,
    CreatecourseFormComponent,
    SignupFormComponent,
    NewteamFormComponent,
    ChangepasswordFormComponent,
    PostsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [AuthorsService,
    {provide: ErrorHandler, useClass: AppErrorHandler}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
