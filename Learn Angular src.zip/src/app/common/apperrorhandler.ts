import { ErrorHandler } from "@angular/core";
import { HttpErrorResponse } from '@angular/common/http';

export class AppErrorHandler implements ErrorHandler
{
    handleError(error:HttpErrorResponse)
    {
        console.log(error);
        //alert(error.message);
    }
}