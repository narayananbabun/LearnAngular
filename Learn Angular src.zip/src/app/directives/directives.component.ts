import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  constructor() {
    
   }

  ngOnInit() {
  }

  menu = "Directive";
  users =[];
  viewMode ='map';
  courses = [];

  task = {
    title:'Safe Traversal operators',
    assigne: null
  };

  
  
  loadCourses()
  {
    this.courses =    [
      {
        id:1, name:"Course1"
      },
      {
        id:2, name:"Course2"
      },
      {
        id:3, name:"Course3"
      },
    ];
  }

  trackCourse(index: any, course)
  {
   return  course ? course.id : undefined;
  }
  
  addCourse()
  {

    this.courses.push({id:4, name:"Course4"});
  }
 removeCourse(course)
 {
   let index = this.courses.indexOf(course)
   this.courses.splice(index,1);
 }

}
