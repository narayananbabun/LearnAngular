import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-games',
  templateUrl: './games.component.html',
  styleUrls: ['./games.component.css']
})
export class GamesComponent implements OnInit {

  menu = "Games";
  title = "Welcome to Games";
  showmessage = "Hi this is my message";
  text ="Start";
  isactive = false;
  emailid = "me@games.com"; 

  notice =  "This is a Notice for the game which is used to play the game";
  rating = 5.2255;
  players = 7838;
  price = 78.637  
  releasedate = new Date(2019, 1, 2);



  constructor() { }

  ngOnInit() {
  }

  onsave($event: any){
   // alert("Loading....");
    console.log("Loading", $event);
  }

  oninsidedivClicked()
  {
    console.log("Inside div click");
  }

  stylebindingbuttonClick()
  {
    console.log("style binding button Clickec");
  }

  onKeyup($event)
  {
    if($event.keyCode == 13) console.log("Enter Pressed");

    console.log($event.target.value);
  }

  onKeyup2()
  {
    console.log("Enter is pressed");
  }

  onKeyup3(email)
  {
    console.log(email);
  }


  onKeyup4()
  {
    console.log(this.emailid);
  }
}
