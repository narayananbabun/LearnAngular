import { Component } from '@angular/core';
import { FavouriteComponentEventArgs } from './favourite/favourite.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


  menus: { [key: string]: string } = {
    "app-newteam-form": "New Team",
    "app-createcourse-form": "Create Course",
    "app-games": "games",
    "app-authors": "authors",
    "app-favourite": "favourite",
    "app-movie": "movie",
    "app-lovetweet": "love tweet",
    "app-directives": "directives",
    "app-panel": "panel",
    "app-zippy": "zippy",
    "app-contact-form": "contact form",
    "app-signup-form": "signup form",
    "app-changepassword-form": "change password",
    "app-posts": "posts"
  };

  menu :string = "app-posts";

  // menus: string[] = [

  //   "app-newteam-form",
  //   "app-createcourse-form",
  //   "app-games",
  //   "app-authors",
  //   "app-favourite",
  //   "app-movie",
  //   "app-lovetweet",
  //   "app-directives",
  //   "app-panel",
  //   "app-zippy",
  //   "app-contact-form",
  //   "app-signup-form",
  //   "app-changepassword-form"

  // ]
  ;




  dirtitle = 'Welcome to my Angular';

  post = {
    isFavourite: true,
    title: "favourite"
  };


  onFavouriteChange(eventargs: FavouriteComponentEventArgs) {
    console.log("Favourite component changed:" + eventargs.title + eventargs.isFavourite);
  }

  tweet = {
    body: 'This is testing the tweet',
    likescount: 100,
    liked: true
  }
}
