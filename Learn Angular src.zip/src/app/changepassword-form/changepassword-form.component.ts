import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { customvalidator } from '../common/customvalidator';

@Component({
  selector: 'app-changepassword-form',
  templateUrl: './changepassword-form.component.html',
  styleUrls: ['./changepassword-form.component.css']
})
export class ChangepasswordFormComponent
{
 
  form: FormGroup;

  constructor(fb: FormBuilder) {
    this.form = fb.group({
        oldpassword: fb.control('', [Validators.required],[customvalidator.incorrectPassword]),
        newpassword: fb.control('', [Validators.required]),
        confirmpassword: fb.control('', [Validators.required])
    },{
      validators: [customvalidator.passwordShouldMatch]
    });
    
     this.log();    
  }

  log() {
    console.log(this.form);
  }

  get oldpassword()
  {
      return this.form.get("oldpassword");
  }

  get newpassword()
  {
    return this.form.get("newpassword");
  }

  get confirmpassword()
  {
    return this.form.get("confirmpassword");
  }
}
