import { Component} from '@angular/core';
import { FormGroup, FormArray, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-newteam-form',
  templateUrl: './newteam-form.component.html',
  styleUrls: ['./newteam-form.component.css']
})
export class NewteamFormComponent {
 
  // form = new FormGroup({
  //   name: new FormControl(),
  //   contact: new FormGroup({
  //     email: new FormControl(),
  //     mobile: new FormControl()
  //   }),
  //   teams: new FormArray([])
  // });
  form : FormGroup;
  constructor(fb : FormBuilder)
  {
   this.form = fb.group(
      {
        name: fb.control('Babu', [Validators.required]),
        contact: fb.group(
          {
              email: fb.control('',[]),
              mobile: fb.control('',[])
          }
        ),
        teams: fb.array([]
        )
      }
    )
  }

  addTeam()
  {
    console.log(this.form);
    this.teams.push(new FormControl(this.name.value));
    this.name.setValue("");
  }

    removeTeam(team : FormControl )
    {
      let index = this.teams.controls.indexOf(team);
      this.teams.removeAt(index);
    }

  get teams()
  {
      return this.form.get('teams') as FormArray;
  }

  get name()
  {
    return this.form.get("name") as FormControl;
  }

  
}
