import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LovetweetComponent } from './lovetweet.component';

describe('LovetweetComponent', () => {
  let component: LovetweetComponent;
  let fixture: ComponentFixture<LovetweetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LovetweetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LovetweetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
