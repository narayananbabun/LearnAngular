import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'titlecase'
})
export class TitlecasePipe implements PipeTransform {

  transform(value: string): any {

   let prepositions: string[] =  ["the", "of" ,"is"];
   let title : string[]= [];
   
   let i = 0;
   value.split(' ').forEach(element => {
    (prepositions.includes(element.toLowerCase()) && i > 1) ? title.push(element.toLowerCase()) :  title.push(this.toTitleCase(element));
        i++;
    });
   return title.join(" ");
  }

  toTitleCase(value :string)
  {
    return  value.substring(0,1).toUpperCase() + ((value.length >  1) ? value.substring(1, value.length).toLowerCase() : "");
  }


}
