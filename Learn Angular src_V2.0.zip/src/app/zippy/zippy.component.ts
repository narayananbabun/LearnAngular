import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-zippy',
  templateUrl: './zippy.component.html',
  styleUrls: ['./zippy.component.css']
})
export class ZippyComponent implements OnInit {

  isClosed = true;
  @Input('title') title :string;
  
  constructor() { }

  ngOnInit() {
  }

  toggle()
  {
    this.isClosed = !this.isClosed;
  }

}
