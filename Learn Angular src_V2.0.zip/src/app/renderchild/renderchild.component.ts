import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-renderchild',
  templateUrl: './renderchild.component.html',
  styleUrls: ['./renderchild.component.css']
})
export class RenderchildComponent implements OnInit {

  menu :string= "";
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    console.log(this.route);
    this.menu = this.route.routeConfig.path;
  }

  tweet = {
    body: 'This is testing the tweet',
    likescount: 100,
    liked: true
  }

  

  

}
