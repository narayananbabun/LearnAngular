import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RenderchildComponent } from './renderchild.component';

describe('RenderchildComponent', () => {
  let component: RenderchildComponent;
  let fixture: ComponentFixture<RenderchildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RenderchildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RenderchildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
