import { Component, OnInit , Input, Output, EventEmitter, ViewEncapsulation} from '@angular/core';


@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  /* template: '<h1><span [(ngModel)]="isFavourite" [class]="class" (click)="iconClick()"  ngDefaultControl ></span></h1>',*/
  styleUrls: ['./favourite.component.css'],
  /*styles:[
    `
    .glyphicon { color: pink; }
    .glyphicon-star { color: green; }
    .glyphicon-star-empty { color: green; }
  ]
    `,*/
    encapsulation: ViewEncapsulation.Emulated
   /*input: ['isFavourite']*/
})
export class FavouriteComponent implements OnInit {
  
  menu = "Favourite";
  save = true;

  constructor() { }
  ngOnInit() {
  }


    //@Input('is-favourite') isFavourite: boolean = false;
    @Input('isFavourite') isSelected: boolean = false;
    //Output property

    @Output('change') click = new EventEmitter();
    


  class = "glyphicon glyphicon-star-empty";
  
  iconClick()
  {
        // console.log("Before:" + this.isFavourite);
        // console.log("Before:" +this.class);

       this.isSelected = this.isSelected ? false : true;
       this.class =  this.isSelected ?	"glyphicon glyphicon-star" : "glyphicon glyphicon-star-empty";
        
        // console.log("A:" + this.isFavourite);
        // console.log("A:" + this.class);

        //Output property

        this.click.emit({title: "PUBG", isFavourite: this.isSelected}) ;
  }



}

export interface FavouriteComponentEventArgs
{
  title: string;
  isFavourite: false;
}

