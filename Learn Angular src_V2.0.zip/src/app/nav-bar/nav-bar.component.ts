import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'navbar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  @Input('menus')menus : any;
  menu = "app-signup-form";
  isNavbarCollapsed = true;
  constructor() { }

  ngOnInit() {
  }

}
