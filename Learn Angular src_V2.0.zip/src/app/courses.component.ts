import { Component } from '@angular/core';

@Component({
    selector: 'courses',    
    template: ''
  })

export class CoursesComponent{
menu = "Courses";
}