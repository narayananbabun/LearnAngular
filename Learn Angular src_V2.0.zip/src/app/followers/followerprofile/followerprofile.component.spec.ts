import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowerprofileComponent } from './followerprofile.component';

describe('FollowerprofileComponent', () => {
  let component: FollowerprofileComponent;
  let fixture: ComponentFixture<FollowerprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FollowerprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FollowerprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
