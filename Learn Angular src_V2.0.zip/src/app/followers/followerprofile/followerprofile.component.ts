import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-followerprofile',
  templateUrl: './followerprofile.component.html',
  styleUrls: ['./followerprofile.component.css']
})
export class FollowerprofileComponent implements OnInit {

  constructor(private route: ActivatedRoute, private router: Router) { 
 
  }

  ngOnInit() {

    //use this when we dont want to user to stay in the same page and wanted to go back and forth else use the observable
    console.log("using spanpshot:" ,this.route.snapshot.paramMap.get("id"));

    //use the observable
    this.route.paramMap.subscribe(params => {
      console.log(params);
      let id : number = +params.get('id');
      console.log(id);
    })
  }

  submit()
  {
      this.router.navigate(['/followers'], 
        { queryParams: {id: 1, order: 'newest'}
  });
  }
}
