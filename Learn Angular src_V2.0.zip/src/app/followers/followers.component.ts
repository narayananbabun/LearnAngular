import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FollowersService } from '../services/followers.service';
import { Observable } from 'rxjs';
import {combineLatest} from "rxjs/index";
import { ActivatedRoute } from '@angular/router';
import { identifierModuleUrl } from '@angular/compiler';
import { switchMap, map } from 'rxjs/operators';

@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {

  followers: any[] = [];

  constructor(private route: ActivatedRoute,
    private service: FollowersService) { }

  ngOnInit() {

    combineLatest([this.route.paramMap,
    this.route.queryParamMap])
      .pipe(
          switchMap(combined =>  {
                    let id = combined[0].get("id");
                    let page = combined[1].get("page");
                    return this.service.getAll()
                  })
          )
   .subscribe(
            (response: any) =>            {
              this.followers = response;
              console.log( this.followers);
            }
          );

      }
  }


