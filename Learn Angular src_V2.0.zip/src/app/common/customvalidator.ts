import { AbstractControl, ValidationErrors, FormControl } from '@angular/forms';
import { promise } from 'protractor';

export class customvalidator {

    static cannotContainSpace(c: AbstractControl): ValidationErrors | null {
        if ((c.value as string).indexOf(' ') > -1) {
            return {
                cannotContainSpace: true
            };
        }
        return null;
    }

    //This for Ascynchronous Validation from the server
    static shouldBeUnique(c: AbstractControl): Promise<ValidationErrors | null> {
        console.log("control:" + c.value);
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (c.value === "babubabu") {
                    resolve({ shouldBeUnique: true });
                }
                else
                    resolve(null);
            }, 2000)
        }
        );


    }

    static incorrectPassword(c: AbstractControl): Promise<ValidationErrors | null> {
        console.log("control: " + c.value);
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (c.value != "1234") {
                    resolve({ incorrectPassword: true });
                }
                else {
                    resolve(null);
                }
            })
        }
        );
    }

    //Check for same old and new password and confirm password
    static passwordShouldMatch(c: AbstractControl): ValidationErrors | null {
        let oldPassword = c.get("oldpassword");
        let newPassword = c.get("newpassword");
        let confirmPassword = c.get("confirmpassword");

        //check same old and new password
        if (oldPassword.value === newPassword.value)
            return { sameOldAndNewPassword: true ,
                oldPassword: oldPassword.value,
                newPassword: newPassword.value
            };

        // Check for new and confirm password
        if (newPassword.value !== confirmPassword.value)
            return {
                confirmpasswordShouldMatch: true,
                newPassword: newPassword.value,
                oldPassword: oldPassword.value
            };

        return null;
    }
}