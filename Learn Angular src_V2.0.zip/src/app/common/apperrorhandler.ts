import { ErrorHandler } from "@angular/core";
import { HttpErrorResponse } from '@angular/common/http';

export class AppErrorHandler implements ErrorHandler
{
    handleError(error:HttpErrorResponse)
    {
        console.log("Error:" , error);
        //alert(error.message);
    }
}