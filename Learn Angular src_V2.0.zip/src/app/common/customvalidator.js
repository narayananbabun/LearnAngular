"use strict";
exports.__esModule = true;
var customvalidator = /** @class */ (function () {
    function customvalidator() {
    }
    customvalidator.cannotContainSpace = function (c) {
        if (c.value.indexOf(' ') > -1) {
            return {
                cannotContainSpace: true
            };
        }
        return null;
    };
    //This for Ascynchronous Validation from the server
    customvalidator.shouldBeUnique = function (c) {
        console.log("control:" + c.value);
        return new Promise(function (resolve, reject) {
            setTimeout(function () {
                if (c.value === "babubabu") {
                    resolve({ shouldBeUnique: true });
                }
                else
                    resolve(null);
            }, 2000);
        });
    };
    return customvalidator;
}());
exports.customvalidator = customvalidator;
