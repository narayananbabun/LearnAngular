import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-lovetweet',
  templateUrl: './lovetweet.component.html',
  styleUrls: ['./lovetweet.component.css']
})
export class LovetweetComponent  {

  @Input() likescount: number = 0;
  @Input() liked:boolean;
  menu = "Tweet"

  onHeartClick()
  {
    this.liked = !this.liked
    this.likescount+= (this.liked) ? 1 : - 1 ;
  }

}
