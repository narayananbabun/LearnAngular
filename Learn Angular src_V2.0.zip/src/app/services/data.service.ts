import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { NotFoundError } from '../common/not-FoundError';
import { AppError } from '../common/app-error';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private url: string, private http: HttpClient) {
  }

  getAll(): Observable<any> {
    return this.http.get(this.url)
      .pipe(
        map( response  => response ),
        catchError(err => { return this.handleError(err)}) // this is another way of calling the catchError as in below get
      );
  }

  get(id?: any): Observable<any> {
    const url = `${this.url}/${(id != null ? id : "")}`;
    return this.http.get(url)
      .pipe(
        map( response  => response),
        catchError(this.handleError)
      );
  }

  post(post: any): Observable<any> {
    return this.http.post(this.url, JSON.stringify(post))
      .pipe(
        map( response  => response ),
        catchError(this.handleError)
      );
  }


  patch(post: any): Observable<any> {
    const url = `${this.url}/${post.id}`;
    return this.http.patch(url, post)
      .pipe(
        map( response  =>  response  ),
        catchError(this.handleError)
      );
  }

  delete(id: any): Observable<any> {
    const url = `${this.url}/${id}`;
    return this.http.delete(url)
      .pipe(
        map( response  =>  response  ),
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse): Observable<any> {
    if (error.status === 404)
      return throwError(new NotFoundError(error));
    else
      return throwError(new AppError(error));
  }

 }
