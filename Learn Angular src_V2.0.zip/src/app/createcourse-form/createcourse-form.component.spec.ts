import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatecourseFormComponent } from './createcourse-form.component';

describe('CreatecourseFormComponent', () => {
  let component: CreatecourseFormComponent;
  let fixture: ComponentFixture<CreatecourseFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatecourseFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatecourseFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
