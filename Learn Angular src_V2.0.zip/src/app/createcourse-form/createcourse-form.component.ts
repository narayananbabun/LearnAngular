import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createcourse-form',
  templateUrl: './createcourse-form.component.html',
  styleUrls: ['./createcourse-form.component.css']
})
export class CreatecourseFormComponent implements OnInit {

  categories: any[] = [
    { id: 1, name: "Development" },
    { id: 2, name: "Arts" },
    { id: 2, name: "Languages" }
  ];

  constructor() { }

  ngOnInit() {
  }

  create(f: any) {
    console.log("Created new Category");
    console.log(f);
  }
}

