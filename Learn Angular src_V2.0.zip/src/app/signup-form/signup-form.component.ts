import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { customvalidator } from '../common/customvalidator';


@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.css']
})
export class SignupFormComponent {

  form = new FormGroup(
    {
      account: new FormGroup({
        username: new FormControl('',
          [Validators.required, Validators.minLength(3), customvalidator.cannotContainSpace],
          [customvalidator.shouldBeUnique]),
        password: new FormControl('',
          [Validators.required, Validators.minLength(3), customvalidator.cannotContainSpace, Validators.maxLength(16)
            , Validators.pattern(new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*<>])(?=.{8,16})"))
          ],
          [customvalidator.shouldBeUnique])
        })
    }
  );

  get username() {
    return this.form.get('account.username');
  }

  get password() {
    return this.form.get('account.password');
  }

  log(x: any) {
    console.log(x);
  }

  login() {
    //call from a service to return the errors
    this.form.setErrors(
      {
        invalidLogin: true
      }
    );
  }
}



